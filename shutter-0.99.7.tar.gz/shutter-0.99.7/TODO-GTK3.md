drawing: rulers
ssh -X is broken
selection: cursor XY stickiness to edges
hidpi: fix possible issues with: multiple screens, subwindow captures, menu capture
