---
name: Question
about: Ask a question about installing, configuring or using Shutter
title: ''
labels: question
assignees: ''

---


