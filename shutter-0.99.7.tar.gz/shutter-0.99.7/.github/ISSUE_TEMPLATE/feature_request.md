---
name: Feature request
about: Suggest an idea for Shutter
title: ''
labels: enhancement
assignees: ''

---

#### Description of requested feature:


#### Reasons for adding feature:


#### Extra information, such as Shutter version, operating system and ideas for how to implement:
