---
name: Bug report
about: Create a report describing a bug in Shutter
title: ''
labels: bug
assignees: ''

---

#### Brief summary of issue


#### Steps to reproduce the issue

1. 
2. 
3. 

#### Error output


#### Extra information, such as Shutter version, display server in use (Xorg or Wayland), operating system and ideas for how to solve:
