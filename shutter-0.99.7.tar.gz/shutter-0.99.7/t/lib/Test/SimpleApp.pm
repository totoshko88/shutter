package Test::SimpleApp;

use Moo;

1;
